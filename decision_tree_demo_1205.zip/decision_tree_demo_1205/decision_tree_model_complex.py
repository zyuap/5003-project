from __future__ import division
import operator
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import col
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from networkx.drawing.nx_agraph import graphviz_layout


sc = SparkContext("local", "Decision Tree")
sqlContext = SQLContext(sc)
attr_name_info_gain = {}
attr_name_gain_ratio = {}
G = nx.DiGraph()
attrs = ["outlook","temp","humidity","wind"]
attrs_type = {"outlook":"string","temp":"string","humidity":"string","wind":"string"}


def calculate_info_gain(entropy, joined_df, total_elements):

    joined_df.show()

    attr_entropy = 0.0
    for anAttributeData in joined_df.rdd.collect():
        yes_class_count = anAttributeData[1]
        no_class_count = anAttributeData[2]
        if yes_class_count is None:
            yes_class_count = 0
        elif no_class_count is None:
            no_class_count = 0

        count_of_class = yes_class_count + no_class_count
        # do the summation part e.g. if age is 56, 60, 45 then its sum of entropy for each of these element
        classmap = {'yes' : yes_class_count, 'no' : no_class_count}
        attr_entropy = attr_entropy + ((count_of_class / total_elements) *\
                                       calculate_entropy(count_of_class, classmap))

    gain = entropy - attr_entropy

    return gain


def calculate_gain_ratio(entropy, joined_df, total_elements):
    split_info = 0.0
    gain = calculate_info_gain(entropy, joined_df, total_elements)
    attr_map = {}

    for anAttributeData in joined_df.rdd.collect():
        yes_class_count = anAttributeData[1]
        no_class_count = anAttributeData[2]
        if yes_class_count is None:
            yes_class_count = 0
        elif no_class_count is None:
            no_class_count = 0

        count_of_class = yes_class_count + no_class_count
        attr_map[anAttributeData[0]] = count_of_class

        split_info = calculate_entropy(total_elements, attr_map)

    gain_ratio = gain/split_info

    return gain_ratio


def get_attr_info_gain_data_prep(attr_name, data, entropy, total_elements, where_condition, attr_select_method):

    if not where_condition:
        attr_grp_y = data.where(col('y') == 'yes').groupBy(attr_name).agg({"y": 'count'})\
            .withColumnRenamed('count(y)','played_count')
    else:
        attr_grp_y = data.where(" y like '%yes%'  " + where_condition).groupBy(attr_name).agg({"y": 'count'})\
            .withColumnRenamed('count(y)','played_count')

    if not where_condition:
        attr_grp_n = data.where(col('y') == 'no').groupBy(attr_name).agg({"y": 'count'})\
            .withColumnRenamed(attr_name,'n_' + attr_name)\
            .withColumnRenamed('count(y)','not_played_count')
    else:
        attr_grp_n = data.where(" y like '%no%'  " + where_condition).groupBy(attr_name).agg({"y": 'count'})\
            .withColumnRenamed(attr_name,'n_' + attr_name)\
            .withColumnRenamed('count(y)','not_played_count')

    joined_df = attr_grp_y.join(attr_grp_n, on = [col(attr_grp_y.columns[0]) == col(attr_grp_n.columns[0])], how='outer' )\
        .withColumn("total", col(attr_grp_y.columns[0]) + col(attr_grp_n.columns[0]))\
        .select(attr_grp_y.columns[0], attr_grp_y.columns[1],\
                 attr_grp_n.columns[1]) \

    gain_for_attribute = calculate_info_gain(entropy, joined_df, total_elements)
    gain_ratio_for_attribute = calculate_gain_ratio(entropy, joined_df, total_elements)

    attr_name_info_gain[attr_name] = gain_for_attribute
    attr_name_gain_ratio[attr_name] = gain_ratio_for_attribute

    if attr_select_method == 'info gain':
        print('\ninfo_gain for each attribute:\n',attr_name_info_gain)
    if attr_select_method == 'gain ratio':
        print('\ngain_ratio for each attribute:\n', attr_name_gain_ratio)


def calculate_entropy(total_elements, elements_in_each_class):
    # for target set S having 2 class 0 and 1, the entropy is -p0logp0 -p1logp1
    # here the log is of base 2
    # elements_in_each_class is a dictionary where the key is class label and the
    # value is number of elements in that class
    keysInMap = list(elements_in_each_class.keys())
    entropy = 0.0

    for aKey in keysInMap:
        number_of_elements_in_class = elements_in_each_class.get(aKey)
        if number_of_elements_in_class == 0:
            continue
        ratio = number_of_elements_in_class/total_elements
        entropy = entropy - ratio * np.log2(ratio)

    return entropy


def process_dataset(excludedAttrs, data, played, notplayed, where_condition, attr_select_method):
    total_elements = played + notplayed
    subs_info = {"played": played, "notplayed": notplayed}
    entropy = calculate_entropy(total_elements, subs_info)
    # print("entropy is " + str(entropy))
    global attr_name_info_gain, attr_name_gain_ratio
    attr_name_info_gain = dict()
    attr_name_gain_ratio = dict()

    print('processed attributes: ', excludedAttrs)

    for attr in attrs:
        if attr not in excludedAttrs:
            get_attr_info_gain_data_prep(attr, data, entropy, total_elements, where_condition, attr_select_method)


def build_tree(max_gain_attr, processed_attrs, data, where_condition, attr_select_method):
    attrValues = sqlContext.sql("select distinct " + max_gain_attr + " from data  where 1==1 " + where_condition)

    orig_where_condition = where_condition

    for aValueForMaxGainAttr in attrValues.rdd.collect():
        adistinct_value_for_attr = aValueForMaxGainAttr[0]
        G.add_edges_from([(max_gain_attr, adistinct_value_for_attr)])

        if attrs_type[max_gain_attr] == "string":
            where_condition = str(orig_where_condition + " and " + max_gain_attr + "=='" + adistinct_value_for_attr + "'")
        else:
            where_condition = str(orig_where_condition + " and " + max_gain_attr + "==" + adistinct_value_for_attr)

        played_for_attr = sqlContext.sql("select * from data where y like '%yes%' " + where_condition).count()
        notplayed_for_attr = sqlContext.sql("select * from data where y like '%no%' " + where_condition).count()

        # if either has zero value then entropy for this attr will be zero and its the last attr in the tree
        leaf_values = []
        if played_for_attr == 0 or notplayed_for_attr == 0:
            leaf_node = sqlContext.sql("select distinct y from data where 1==1 " + where_condition)
            for leaf_node_data in leaf_node.rdd.collect():
                G.add_edges_from([(adistinct_value_for_attr, str(leaf_node_data[0]))])
            continue

        process_dataset(processed_attrs, data, played_for_attr, notplayed_for_attr, where_condition, attr_select_method)

        # if not attr_name_info_gain:  # we processed all attributes
        if (attr_select_method == 'info gain' and not attr_name_info_gain)\
                or (attr_select_method == 'info gain' and not attr_name_gain_ratio):
            # attach leaf node
            leaf_node = sqlContext.sql("select distinct y from data where 1==1 " + where_condition)

            for leaf_node_data in leaf_node.rdd.collect():
                G.add_edges_from([(adistinct_value_for_attr, str(leaf_node_data[0]))])
            continue # we are done for this branch of tree

        # get the attr with max info gain under aValueForMaxGainAttr
        # sort by info gain
        sorted_by_info_gain = sorted(attr_name_info_gain.items(), key=operator.itemgetter(1), reverse=True)
        sorted_by_gian_ratio = sorted(attr_name_gain_ratio.items(), key=operator.itemgetter(1), reverse=True)

        if attr_select_method == 'info gain':
            new_max_gain_attr = sorted_by_info_gain[0][0]
        if attr_select_method == 'gain ratio':
            new_max_gain_attr = sorted_by_gian_ratio[0][0]

        # if sorted_by_info_gain[0][1] == 0:
        if (attr_select_method == 'info gain' and sorted_by_info_gain[0][1] == 0)\
                or (attr_select_method == 'gain ratio' and sorted_by_gian_ratio[0][1] == 0):
            # under this where condition, records dont have entropy
            leaf_node = sqlContext.sql("select distinct y from data where 1==1 " + where_condition)

            # there might be more than one leaf node
            for leaf_node_data in leaf_node.rdd.collect():
                G.add_edges_from([(adistinct_value_for_attr, str(leaf_node_data[0]))])
            continue # we are done for this branch of tree

        G.add_edges_from([(adistinct_value_for_attr, new_max_gain_attr)])
        processed_attrs.append(new_max_gain_attr)
        build_tree(new_max_gain_attr, processed_attrs, data, where_condition, attr_select_method)


def main():
    attr_select_method = 'gain ratio'  # 'info gain'

    data = sqlContext.read.format('com.databricks.spark.csv').option('header', 'true')\
        .option('delimiter', ';').load("./datasets/simple_dataset.csv")

    print('data:')
    data.show()

    # played = data.select('*').where(data.y == 'yes').count()
    # notplayed = data.select('*').where(data.y == 'no').count()

    data.registerTempTable('data')
    played = sqlContext.sql("select * from data WHERE y like  '%yes%' ").count()
    notplayed = sqlContext.sql("select * from data WHERE y like  '%no%' ").count()

    process_dataset([], data, played, notplayed, '', attr_select_method)

    # sort by info gain
    sorted_by_info_gain = sorted(attr_name_info_gain.items(), key=operator.itemgetter(1), reverse=True)

    # sort by gain ratio
    sorted_by_gain_ratio = sorted(attr_name_gain_ratio.items(), key=operator.itemgetter(1), reverse=True)

    processed_attrs = []

    if attr_select_method == 'info gain':
        selected_attr = sorted_by_info_gain[0][0]
    if attr_select_method == 'gain ratio':
        selected_attr = sorted_by_gain_ratio[0][0]

    print('\n ♥ ♥ ♥ Get the root node: ', selected_attr,'♥ ♥ ♥')

    processed_attrs.append(selected_attr)
    build_tree(selected_attr, processed_attrs, data, '', attr_select_method)

    nx.draw(G, with_labels=True, pos=nx.random_layout(G))
    plt.show()

main()
